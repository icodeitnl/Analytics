import { DataSource } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { InvoicesService } from '../invoices.service';
import { of } from 'rxjs/observable/of';
import { map } from 'rxjs/operators';

import { Observable, of as ObserUsya, merge } from 'rxjs';


export interface Invoice {
    
   invoice: number;
   date: string;
   customer:  string;
   status: string;
   assigned: string;
   balance: number;
   paid: number;
   total:number;
}

const NEW_DATA: Invoice[] = [
    {"invoice": 242,"date": "2020-06-01","customer": "Marie Curie","status": "pending","assigned": "Muhammad Ali","balance": 18,"paid": 2340,"total": 2030},
    {"invoice": 898,"date": "2020-06-02","customer": "Fred Haise","status": "paid","assigned": "Mike Tyson","balance": 283,"paid": 657,"total": 13340},
    {"invoice": 283,"date": "2020-06-03","customer": "Bill Bryson","status": "transferred","assigned": "Rocky Balboa","balance": 493,"paid": 1230,"total": 623},
    {"invoice": 657,"date": "2020-06-04","customer": "Neil Armstrong","status": "pending","assigned": "Muhammad Ali","balance": 32,"paid": 1000,"total": 340},
    {"invoice": 209,"date": "2020-06-05","customer": "Jim Lovel","status": "paid","assigned": "Rocky Balboa","balance": 34,"paid": 1000,"total": 670},
    {"invoice": 178,"date": "2020-06-06","customer": "Roger B. Chaffee","status": "transferred","assigned": "Rocky Balboa","balance": 67,"paid": 6732,"total": 8790},
    {"invoice": 934,"date": "2020-06-07","customer": "Yuri Gagarin","status": "pending","assigned": "Muhammad Ali","balance": 34,"paid": 2130,"total": 120},
    {"invoice": 298,"date": "2020-06-08","customer": "Yuval Harari","status": "paid","assigned": "Muhammad Ali","balance": 209,"paid": 1908,"total": 62743},
    {"invoice": 382,"date": "2020-06-09","customer": "Jessie Ware","status": "transferred","assigned": "Muhammad Ali","balance": 237,"paid": 1233,"total": 90657},
    {"invoice": 986,"date": "2020-06-10","customer": "Agatha Christie","status": "pending","assigned": "Rocky Balboa","balance": 1067,"paid": 8974,"total": 43278},
    {"invoice": 283,"date": "2020-06-11","customer": "Bill Bryson","status": "paid","assigned": "Rocky Balboa","balance": 853,"paid": 10,"total": 5847},
    {"invoice": 902,"date": "2020-06-12","customer": "Linda Paul","status": "transferred","assigned": "Mike Tyson","balance": 21,"paid": 1120,"total": 4350},
    {"invoice": 201,"date": "2020-06-13","customer": "Indiana Jones","status": "pending","assigned": "Muhammad Ali","balance": 56,"paid":670,"total": 24530},
    {"invoice": 893,"date": "2020-06-14","customer": "Luke Skywalker","status": "paid","assigned": "Rocky Balboa","balance": 90,"paid": 3420,"total": 54},
    {"invoice": 398,"date": "2020-06-15","customer": "Dan Ariely","status": "transferred","assigned": "Muhammad Ali","balance": 87,"paid": 234,"total": 5650},
    {"invoice": 283,"date": "2020-06-16","customer": "Bill Bryson","status": "pending","assigned": "Mike Tyson","balance": 56,"paid": 87,"total": 5760},
    {"invoice": 674,"date": "2020-06-17","customer": "Buzz Aldrin","status": "paid","assigned": "Muhammad Ali","balance": 238,"paid": 56756,"total": 987},
    {"invoice": 902,"date": "2020-06-18","customer": "Rusty Schweickart","status": "transferred","assigned": "Rocky Balboa","balance": 384,"paid": 1000,"total": 23476},
    {"invoice": 984,"date": "2020-06-19","customer": "James McDivitt","status": "paid","assigned": "Rocky Balboa","balance": 892,"paid": 456,"total": 543},
    {"invoice": 986,"date": "2020-06-20","customer": "Agatha Christie","status": "pending","assigned": "Mike Tyson","balance": 382,"paid": 213,"total": 3120},
    {"invoice": 145,"date": "2020-06-21","customer": "Richard Feynman","status": "pending","assigned": "Muhammad Ali","balance": 57,"paid": 4760,"total": 123},
    {"invoice": 211,"date": "2020-06-22","customer": "Jack Nicholson","status": "paid","assigned": "Rocky Balboa","balance": 1120,"paid": 98987,"total": 2654},
    {"invoice": 377,"date": "2020-06-23","customer": "Ranulph Fayennes","status": "pending","assigned": "Muhammad Ali","balance": 420,"paid": 679,"total": 867},
    {"invoice": 777,"date": "2020-06-24","customer": "Mark Manson","status": "paid","assigned": "Rocky Balboa","balance": 287,"paid": 5676,"total": 879},
    {"invoice": 555,"date": "2020-06-25","customer": "Ed White","status": "transferred","assigned": "Rocky Balboa","balance": 90,"paid": 123,"total": 213},
]

 export class InvoicesDataSource extends DataSource<Invoice> {
 data: Invoice[] = NEW_DATA;
 paginator: MatPaginator;
 sort: MatSort;

 constructor() {
   super();
 }

 connect(): Observable<Invoice[]> {
    // Combine everything that affects the rendered data into one update
    // stream for the data-table to consume.
    const dataMutations = [
      ObserUsya(this.data),
      this.paginator.page,
      this.sort.sortChange
    ];


return merge(...dataMutations).pipe(map(() => {
      return this.getPagedData(this.getSortedData([...this.data]));
    }));
  }

  disconnect() {}


  private getPagedData(data: Invoice[]) {
    const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
    return data.splice(startIndex, this.paginator.pageSize);
  }

 
  private getSortedData(data: Invoice[]) {
    if (!this.sort.active || this.sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      const isAsc = this.sort.direction === 'asc';
      switch (this.sort.active) {
        case 'customer': return compare(a.customer, b.customer, isAsc);
        case 'invoice': return compare(+a.invoice, +b.invoice, isAsc);
        case 'balance': return compare(+a.balance, +b.balance, isAsc);
        case 'total': return compare(+a.total, +b.total, isAsc);
        case 'paid': return compare(+a.paid, +b.paid, isAsc);
        case 'date': return compare(+a.date, +b.date, isAsc);
        case 'status': return compare(a.status, b.status, isAsc);
        case 'total': return compare(+a.total, +b.total, isAsc);
        case 'assigned': return compare(a.assigned, b.assigned, isAsc);







        default: return 0;
      }
    });
  }
}

/** Simple sort comparator for example invoice/customer columns (for client-side sorting). */
function compare(a: string | number, b: string | number, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
