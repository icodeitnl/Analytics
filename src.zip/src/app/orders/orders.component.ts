import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs/operators';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { StoreSummaryService} from './store-summary.service';
import { StoreSummary } from './store-summary';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent{

  
  cardLayout = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
   map(({ matches }) => {
     if (matches) {
         return {
         columns: 1,
         miniCard: { cols: 1, rows: 1 },
         chart: { cols: 1, rows: 2 },
         table: { cols: 1, rows: 5},
       };
     }

    return {
       columns: 5,
       orderCard: { cols: 1, rows: 1 },
       chart: { cols: 2, rows: 2},
       table: { cols: 5, rows: 5 },
     };
   })
 );


 orderCardData: StoreSummary[];

 constructor(private breakpointObserver: BreakpointObserver, private summaryService: StoreSummaryService) {}

 ngOnInit() {
   this.summaryService.getStoreSummary().subscribe({
     next: summaryData => {
       this.orderCardData = summaryData;
     }
   });
 } 
}


