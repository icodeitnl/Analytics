import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { StoreSummary } from './store-summary';

@Injectable({
  providedIn: 'root'
})
export class StoreSummaryService {

  getStoreSummary(): Observable<StoreSummary[]> {
    return of([
     
      { title: "Amount Ordered", value: "9390000", isIncrease: true, color: "accent", percentValue: "0.4565", icon: "account_balance_wallet", isCurrency: true },
      { title: "Amount Open", value: "274200", isIncrease: true, color: "warn", percentValue: "0.4565", icon: "request_quote", isCurrency: true},
      { title: "Quantity Ordered", value: "183800", isIncrease: false, color: "secondary", percentValue: "0.8361", icon: "shopping_bag", isCurrency: true },
      { title: "Quantity Open", value: "1519", isIncrease: false, color: "warn", percentValue: "0.8361", icon: "shopping_cart", isCurrency: true},
      { title: "Quantity On-Hold", value: "0", isIncrease: false, color: "primary", percentValue: "0.8361", icon: "shopping_basket", isCurrency: true }

    ]);
  }

  constructor() { }
}