import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs/operators';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { StoreSummaryService} from './store-summary.service';
import { StoreSummary } from './store-summary';

@Component({
  selector: 'app-leads',
  templateUrl: './leads.component.html',
  styleUrls: ['./leads.component.css']
})
export class LeadsComponent {


cardLayout = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
   map(({ matches }) => {
     if (matches) {
       return {
         columns: 1,
         miniCard: { cols: 1, rows: 1 },
         chart: { cols: 1, rows: 2 },
         table: { cols: 1, rows: 4 },
       };
     }

    return {
       columns: 4,
       miniCard: { cols: 1, rows: 1 },
       chart: { cols: 2, rows: 2 },
       table: { cols: 4, rows: 4 },
     };
   })
 );


 miniCardData: StoreSummary[];

 constructor(private breakpointObserver: BreakpointObserver, private summaryService: StoreSummaryService) {}

 ngOnInit() {
   this.summaryService.getStoreSummary().subscribe({
     next: summaryData => {
       this.miniCardData = summaryData;
     }
   });
 } 
}


