import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { StoreSummary } from './store-summary';

@Injectable({
  providedIn: 'root'
})
export class StoreSummaryService {

  getStoreSummary(): Observable<StoreSummary[]> {
    return of([
      { title: "Total Sales", value: "657934", isIncrease: true, color: "primary", percentValue: "0.5383", icon: "payments", isCurrency: true },
      { title: "Average Order Value", value: "4325", isIncrease: false, color: "warn", percentValue: "0.2544", icon: "local_atm", isCurrency: true },
      { title: "Total Orders", value: "75632", isIncrease: true, color: "accent", percentValue: "0.4565", icon: "shopping_cart", isCurrency: false },
      { title: "Returning Customers", value: "2134", isIncrease: false, color: "secondary", percentValue: "0.8361", icon: "portrait", isCurrency: false }
    ]);
  }

  constructor() { }
}