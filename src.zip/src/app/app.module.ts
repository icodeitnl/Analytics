import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app.routing';
import { NavbarModule } from './shared/navbar/navbar.module';
import { FooterModule } from './shared/footer/footer.module';
import { SidebarModule } from './sidebar/sidebar.module';
import { LbdModule } from'./lbd/lbd.module';
import { AppComponent } from './app.component';
import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { NguiMapModule} from '@ngui/map';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatGridListModule} from '@angular/material/grid-list';
import { MatCardModule} from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { LeadsComponent } from './leads/leads.component';
import { CompetitorsComponent } from './competitors/competitors.component';
import { MarketingComponent } from './marketing/marketing.component';
import { InvoicesComponent } from './invoices/invoices.component';
import { PredictionsComponent } from './predictions/predictions.component';
import { OrdersComponent } from './orders/orders.component';
import { ChartsModule } from 'ng2-charts';
import { SalesTrafficChartComponent } from './charts/sales-traffic-chart/sales-traffic-chart.component';
import { StoreSessionsChartComponent } from './charts/store-sessions-chart/store-sessions-chart.component';
import { ProductSalesChartComponent } from './charts/product-sales-chart/product-sales-chart.component';
import { AnnualSalesChartComponent } from './charts/annual-sales-chart/annual-sales-chart.component';
import { OrdersTableComponent } from './orders-table/orders-table.component';
import { MatChipsModule } from '@angular/material/chips';
import { MiniCardComponent} from './mini-card/mini-card.component';
import { OrderCardComponent} from './order-card/order-card.component';
import { PoSupplierComponent } from './charts/po-supplier/po-supplier.component';
import { PoItemComponent } from './charts/po-item/po-item.component';
import { PoBuComponent } from './charts/po-bu/po-bu.component';



@NgModule({
  imports: [
    LbdModule,
    BrowserAnimationsModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule, 
    RouterModule,
    HttpClientModule,
    NavbarModule,
    FooterModule,
    SidebarModule,
    AppRoutingModule,
    NguiMapModule.forRoot({
      apiUrl: 'https://maps.google.com/maps/api/js?libraries=visualization,places,drawing'
    }),
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    ChartsModule,
    MatGridListModule,
    MatCardModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatChipsModule,  
  ],
  declarations: [
    AppComponent,
    AdminLayoutComponent,
    LeadsComponent,
    CompetitorsComponent,
    MarketingComponent,
    InvoicesComponent,
    PredictionsComponent,
    SalesTrafficChartComponent,
    AnnualSalesChartComponent,
    StoreSessionsChartComponent,
    ProductSalesChartComponent,
    OrdersTableComponent,
    MiniCardComponent,
    OrderCardComponent,
    OrdersComponent,
    PoSupplierComponent,
    PoItemComponent,
    PoBuComponent,
  ],
  
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
