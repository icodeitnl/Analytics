import { Component, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { Label } from 'ng2-charts';

@Component({
  selector: 'app-po-item',
  templateUrl: './po-item.component.html',
  styleUrls: ['./po-item.component.css']
})
export class PoItemComponent implements OnInit {

  public barChartOptions: ChartOptions = {
    responsive: true,
  };
  public barChartLabels: Label[] = ['August', 'September', 'October', 'November', 'December'];
  public barChartType: ChartType = 'bar';
  public barChartLegend = true;
  public barChartPlugins = [];

public barChartData: ChartDataSets[] = [
    {
      data: [65, 59, 80, 76, 32], label: 'Fuel'
      , backgroundColor: '#7c8500', hoverBackgroundColor: '#f57f17', hoverBorderColor: '#f9a825', borderColor: '#000'
    },


    {
      data: [28, 48, 40, 77, 91 ], label: 'Advanced Network Devices'
      , backgroundColor: '#bc5100', hoverBackgroundColor: '#e4e65e', hoverBorderColor: '#ffb04c', borderColor: '#000'
    },

    {
      data: [76, 58, 22, 44, 21], label: 'Legal Seminar'
      , backgroundColor: '#00796b', hoverBackgroundColor: '#5c6bc0', hoverBorderColor: '#ffb04c', borderColor: '#000'
    }
  ];
  constructor() { }

  ngOnInit() {
  }

}
