import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PoBuComponent } from './po-bu.component';

describe('PoBuComponent', () => {
  let component: PoBuComponent;
  let fixture: ComponentFixture<PoBuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PoBuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PoBuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
