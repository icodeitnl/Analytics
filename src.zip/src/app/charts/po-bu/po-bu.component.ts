import { Component, OnInit } from '@angular/core';
import { ChartOptions, ChartType } from 'chart.js';
import { Label, SingleDataSet } from 'ng2-charts';

@Component({
  selector: 'app-po-bu',
  templateUrl: './po-bu.component.html',
  styleUrls: ['./po-bu.component.css']
})
export class PoBuComponent implements OnInit {

  public pieChartOptions: ChartOptions = {
    responsive: true,
  };
  public pieChartLabels: Label[] = ['Financial', 'Operations', 'Legal', 'IT', 'Real Estate', 'Travel&Fleet', 'HR'];
 public pieChartData: SingleDataSet = [890, 654, 300, 234, 145, 100, 75];
 public pieChartType: ChartType = 'pie';
 public pieChartLegend = true;
 public pieChartPlugins = [];
 public pieChartColors: Array < any > = [{
  backgroundColor: ['#CDDC39', '#8BC34A', '#FFC107','#FF5722', '#5D4037', '#FFA000', '#FFEB3B'],
  borderColor: [],
 }];



  constructor() { }

  ngOnInit() {
  }

}
