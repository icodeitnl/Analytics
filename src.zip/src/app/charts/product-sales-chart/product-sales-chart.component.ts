import { Component, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { Label } from 'ng2-charts';


@Component({
  selector: 'app-product-sales-chart',
  templateUrl: './product-sales-chart.component.html',
  styleUrls: ['./product-sales-chart.component.css']
})
export class ProductSalesChartComponent implements OnInit {

  public radarChartOptions: ChartOptions = {
    responsive: true,
  };
  public radarChartLabels: Label[] = ['Price', 'Durability', 'Promotion', 'Appearence', 'Post-Sales Service', 'Quality', 'Sales Channel'];

  public radarChartData: ChartDataSets[] = [
    { data: [65, 59, 90, 81, 56, 55, 40], 
     label: 'Product A', 
     borderColor: '#c49000',backgroundColor: 'rgba(251,192,45,0.7', pointBackgroundColor: "#fbc02d"},
    { data: [28, 48, 40, 19, 96, 27, 100], 
      label: 'Product B', borderColor: '#b91400',backgroundColor:'rgba(244,81,30,0.7)',pointBackgroundColor: "#f4511e"},
  ];
  public radarChartType: ChartType = 'radar';



  constructor() { }

  ngOnInit() {

}
}
