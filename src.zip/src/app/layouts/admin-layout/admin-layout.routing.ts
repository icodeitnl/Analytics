import { Routes } from '@angular/router';
import { HomeComponent } from '../../home/home.component';
import { UserComponent } from '../../user/user.component';
import { MapsComponent } from '../../maps/maps.component';
import { UpgradeComponent } from '../../upgrade/upgrade.component';
import { MarketingComponent } from '../../marketing/marketing.component';
import { InvoicesComponent } from '../../invoices/invoices.component';
import { PredictionsComponent } from '../../predictions/predictions.component';
import { OrdersComponent } from '../../orders/orders.component';
import { CompetitorsComponent } from '../../competitors/competitors.component';

export const AdminLayoutRoutes: Routes = [
    { path: 'home',           component: HomeComponent },
    { path: 'competitors',    component: CompetitorsComponent },
    { path: 'customer-profitability',    component: MarketingComponent },
    { path: 'user',           component: UserComponent },
    { path: 'procurement',    component: OrdersComponent },
    { path: 'invoices',       component: InvoicesComponent },
    { path: 'intelligence-summary',    component: PredictionsComponent },
    { path: 'maps',           component: MapsComponent },
    { path: 'upgrade',        component: UpgradeComponent },
];
