import { Component, OnInit } from '@angular/core';

declare const $: any;
declare interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    class: string;
}
export const ROUTES: RouteInfo[] = [
    { path: '/home', title: 'Sales and Performance Goals',  icon: 'flaticon-price-tag', class: '' },
    { path: '/competitors', title: 'Competitors',  icon: 'flaticon-users-1', class: '' },
    { path: '/customer-profitability', title: 'Customer Profitability', icon: 'flaticon-calculator', class: '' },
    { path: '/procurement', title: 'Procurement Analysis',  icon:'flaticon-id-card-4', class: '' },
    { path: '/invoices', title: 'Invoices',  icon:'flaticon-file-2', class: '' },
    { path: '/intelligence-summary', title: 'Intenlligence Summary',  icon:'flaticon-controls-1', class: '' },
    { path: '/maps', title: 'Regions',  icon:'flaticon-worldwide', class: '' },
    { path: '/upgrade', title: 'Upgrade to PRO',  icon:'flaticon-locked-4', class: 'active-pro' },

];

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html'
})
export class SidebarComponent implements OnInit {
  menuItems: any[];

  constructor() { }

  ngOnInit() {
    this.menuItems = ROUTES.filter(menuItem => menuItem);
  }
  isMobileMenu() {
      if ($(window).width() > 991) {
          return false;
      }
      return true;
  };
}
