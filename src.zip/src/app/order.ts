export interface Order {
    id: number;
    date: string;
    name: string;
    status: string;
    orderTotal: number;
    paymentMode: string;
}
