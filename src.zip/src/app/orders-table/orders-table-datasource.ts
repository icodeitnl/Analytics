import { DataSource } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { OrdersService } from '../orders.service';
import { of } from 'rxjs/observable/of';
import { map } from 'rxjs/operators';

import { Observable, of as ObserUsya, merge } from 'rxjs';



export interface Order {
    id: number;
    date: string;
    name: string;
    status: string;
    orderTotal: number;
    paymentMode: string;
}

const NEW_DATA: Order[] = [
    {"id": 242,"date": "2020-06-01","name": "Marie Curie","status": "pending","orderTotal": 18,"paymentMode": "cash"},
    {"id": 898,"date": "2020-06-02","name": "Fred Haise","status": "shipped","orderTotal": 283,"paymentMode": "paypal"},
    {"id": 283,"date": "2020-06-03","name": "Bill Bryson","status": "delivered","orderTotal": 493,"paymentMode": "card"},
    {"id": 657,"date": "2020-06-04","name": "Neil Armstrong","status": "pending","orderTotal": 32,"paymentMode": "apple pay"},
    {"id": 209,"date": "2020-06-05","name": "Jim Lovel","status": "shipped","orderTotal": 34,"paymentMode": "google pay"},
    {"id": 178,"date": "2020-06-06","name": "Roger B. Chaffee","status": "delivered","orderTotal": 67,"paymentMode": "store credit"},
    {"id": 934,"date": "2020-06-07","name": "Yuri Gagarin","status": "pending","orderTotal": 34,"paymentMode": "cash"},
    {"id": 298,"date": "2020-06-08","name": "Yuval Harari","status": "shipped","orderTotal": 209,"paymentMode": "paypal"},
    {"id": 382,"date": "2020-06-09","name": "Jessie Ware","status": "delivered","orderTotal": 237,"paymentMode": "card"},
    {"id": 986,"date": "2020-06-10","name": "Agatha Christie","status": "pending","orderTotal": 1067,"paymentMode": "apple pay"},
    {"id": 283,"date": "2020-06-11","name": "Bill Bryson","status": "shipped","orderTotal": 853,"paymentMode": "google pay"},
    {"id": 902,"date": "2020-06-12","name": "Linda Paul","status": "delivered","orderTotal": 21,"paymentMode": "store credit"},
    {"id": 201,"date": "2020-06-13","name": "Indiana Jones","status": "pending","orderTotal": 56,"paymentMode": "cash"},
    {"id": 893,"date": "2020-06-14","name": "Luke Skywalker","status": "shipped","orderTotal": 90,"paymentMode": "paypal"},
    {"id": 398,"date": "2020-06-15","name": "Dan Ariely","status": "delivered","orderTotal": 87,"paymentMode": "card"},
    {"id": 283,"date": "2020-06-16","name": "Bill Bryson","status": "pending","orderTotal": 56,"paymentMode": "apple pay"},
    {"id": 674,"date": "2020-06-17","name": "Buzz Aldrin","status": "shipped","orderTotal": 238,"paymentMode": "google pay"},
    {"id": 902,"date": "2020-06-18","name": "Rusty Schweickart","status": "delivered","orderTotal": 384,"paymentMode": "store credit"},
    {"id": 984,"date": "2020-06-19","name": "James McDivitt","status": "shipped","orderTotal": 892,"paymentMode": "cash"},
    {"id": 986,"date": "2020-06-20","name": "Agatha Christie","status": "pending","orderTotal": 382,"paymentMode": "card"},
    {"id": 145,"date": "2020-06-21","name": "Richard Feynman","status": "pending","orderTotal": 57,"paymentMode": "card"},
    {"id": 211,"date": "2020-06-22","name": "Jack Nicholson","status": "shipped","orderTotal": 1120,"paymentMode": "cash"},
    {"id": 377,"date": "2020-06-23","name": "Ranulph Fayennes","status": "pending","orderTotal": 420,"paymentMode": "paypal"},
    {"id": 777,"date": "2020-06-24","name": "Mark Manson","status": "shipped","orderTotal": 287,"paymentMode": "card"},
    {"id": 555,"date": "2020-06-25","name": "Ed White","status": "delivered","orderTotal": 90,"paymentMode": "store credit"},

]

 export class OrdersTableDataSource extends DataSource<Order> {
 data: Order[] = NEW_DATA;
 paginator: MatPaginator;
 sort: MatSort;

 constructor() {
   super();
 }

 connect(): Observable<Order[]> {
    // Combine everything that affects the rendered data into one update
    // stream for the data-table to consume.
    const dataMutations = [
      ObserUsya(this.data),
      this.paginator.page,
      this.sort.sortChange
    ];


return merge(...dataMutations).pipe(map(() => {
      return this.getPagedData(this.getSortedData([...this.data]));
    }));
  }

  disconnect() {}


  private getPagedData(data: Order[]) {
    const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
    return data.splice(startIndex, this.paginator.pageSize);
  }

 
  private getSortedData(data: Order[]) {
    if (!this.sort.active || this.sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      const isAsc = this.sort.direction === 'asc';
      switch (this.sort.active) {
        case 'name': return compare(a.name, b.name, isAsc);
        case 'id': return compare(+a.id, +b.id, isAsc);
        case 'date': return compare(+a.date, +b.date, isAsc);
        case 'status': return compare(a.status, b.status, isAsc);
        case 'orderTotal': return compare(+a.orderTotal, +b.orderTotal, isAsc);
        case 'paymentMode': return compare(a.paymentMode, b.paymentMode, isAsc);


        default: return 0;
      }
    });
  }
}

/** Simple sort comparator for example ID/Name columns (for client-side sorting). */
function compare(a: string | number, b: string | number, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
